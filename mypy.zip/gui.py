from tkinter import *

window = Tk()

window.title("test")
print("this is test")

window.mainloop()
